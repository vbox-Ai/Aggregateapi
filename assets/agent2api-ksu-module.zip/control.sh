#!/system/bin/sh
# ── Agent2API KernelSU 模块 · 控制入口 ─────────────────────
# 用法: control.sh start|stop|restart|status|rollback
#   start    拉起守护进程（幂等：已在跑就不动）
#   stop     立停止标记并终止网关与守护（守护下一轮看到标记自然退出）
#   restart  stop + start
#   status   打印运行状态
#   rollback 把 bin/agent2api-server.prev 换回主位并重启（一键回滚）
MODDIR=${0%/*}
DATA_DIR=/data/adb/agent2api
BIN="$MODDIR/bin/agent2api-server"
PREV="$MODDIR/bin/agent2api-server.prev"
LOG="$DATA_DIR/server.log"
STOPFLAG="$DATA_DIR/stop.flag"
SUPPID="$DATA_DIR/supervisor.pid"
KSUD=/data/adb/ksu/bin/ksud

PORT=3065
HOST=127.0.0.1
if [ -x "$KSUD" ]; then
  export KSU_MODULE=agent2api
  V=$($KSUD module config get port 2>/dev/null) && [ -n "$V" ] && PORT=$V
  V=$($KSUD module config get host 2>/dev/null) && [ -n "$V" ] && HOST=$V
fi

running() {
  # 健康检查优先（PID 文件可能被竞态删掉但网关活着）；PID 文件只做补充
  if busybox wget -qO- "http://127.0.0.1:$PORT/health" 2>/dev/null | grep -q '"ok"'; then
    return 0
  fi
  P=$(cat "$DATA_DIR/agent2api.pid" 2>/dev/null)
  [ -n "$P" ] && kill -0 "$P" 2>/dev/null
}

do_stop() {
  touch "$STOPFLAG"
  # 杀掉所有守护实例（pkill 快而准；/proc 逐个 grep 扫 30 秒+会制造竞态）
  busybox pkill -f "supervisor.sh" 2>/dev/null
  sleep 1
  busybox pkill -9 -f "supervisor.sh" 2>/dev/null
  kill_gateway
  rm -rf /data/adb/agent2api/supervisor.lock.d 2>/dev/null
  # 按进程名杀网关（--argv0 后进程名正常）+ 扫描兜底（防孤儿占端口：
  # pidfile 可能因崩溃竞态指向旧 PID，孤儿进程会占着 3065 导致新实例起不来）
  killall agent2api-server 2>/dev/null
  for _p in /proc/[0-9]*; do
    _pid=${_p#/proc/}
    [ -r "$_p/cmdline" ] || continue
    if grep -aq "agent2api-server" "$_p/cmdline" 2>/dev/null; then
      grep -aq "ld-linux" "$_p/cmdline" 2>/dev/null && kill "$_pid" 2>/dev/null
    fi
  done
  P=$(cat "$DATA_DIR/agent2api.pid" 2>/dev/null)
  [ -n "$P" ] && kill "$P" 2>/dev/null
  sleep 1
  killall -9 agent2api-server 2>/dev/null
  for _p in /proc/[0-9]*; do
    _pid=${_p#/proc/}
    [ -r "$_p/cmdline" ] || continue
    if grep -aq "ld-linux" "$_p/cmdline" 2>/dev/null && grep -aq "agent2api" "$_p/cmdline" 2>/dev/null; then
      kill -9 "$_pid" 2>/dev/null
    fi
  done
  rm -f "$DATA_DIR/agent2api.pid"
  if [ -x "$KSUD" ]; then
    export KSU_MODULE=agent2api
    $KSUD module config set override.description "Agent2API · 已停止（Action / WebUI 可再次启动）" 2>/dev/null
  fi
}

# 扫杀所有网关实例（含孤儿：pidfile 可能因崩溃竞态指向旧 PID，
# 孤儿占着端口会让新实例永远起不来）
kill_gateway() {
  # pkill 按进程名（--argv0 后 cmdline 首段是 agent2api-server）+ 按 cmdline 匹配 loader 启动的实例
  killall agent2api-server 2>/dev/null
  busybox pkill -f "ld-linux.*agent2api-server" 2>/dev/null
  P=$(cat "$DATA_DIR/agent2api.pid" 2>/dev/null)
  [ -n "$P" ] && kill "$P" 2>/dev/null
  sleep 1
  killall -9 agent2api-server 2>/dev/null
  busybox pkill -9 -f "ld-linux.*agent2api-server" 2>/dev/null
  rm -f "$DATA_DIR/agent2api.pid"
}

do_start() {
  # 已健康运行且守护在岗：不动
  _healthy=0
  busybox wget -qO- "http://127.0.0.1:$PORT/health" 2>/dev/null | grep -q '"ok"' && _healthy=1
  _sup=0
  busybox ps -A 2>/dev/null | grep -q "[s]upervisor.sh" && _sup=1
  [ "$_healthy" = "1" ] && [ "$_sup" = "1" ] && return 0
  # 清掉所有旧守护（含被系统冻结的僵死实例：活着、占锁、不干活）与锁
  busybox pkill -f "supervisor.sh" 2>/dev/null
  sleep 1
  busybox pkill -9 -f "supervisor.sh" 2>/dev/null
  rm -rf /data/adb/agent2api/supervisor.lock.d 2>/dev/null
  # 清孤儿网关（占端口会让新实例起不来）
  kill_gateway
  [ -f "$STOPFLAG" ] && rm -f "$STOPFLAG"
  setsid sh "$MODDIR/supervisor.sh" >/dev/null 2>&1 < /dev/null &
}

do_status() {
  if running; then
    P=$(cat "$DATA_DIR/agent2api.pid" 2>/dev/null)
    H=$(busybox wget -qO- "http://127.0.0.1:$PORT/health" 2>/dev/null)
    echo "运行中 PID=$P 端口=$PORT 健康=$H"
  else
    echo "未运行（端口配置 $PORT）"
  fi
}

do_rollback() {
  if [ ! -f "$PREV" ]; then
    echo "没有上一版本可回滚（bin/agent2api-server.prev 不存在）"
    return 1
  fi
  CUR_VER=$(strings "$BIN" 2>/dev/null | grep -m1 'agent2api-server v\|3\.[0-9]' | head -1)
  do_stop
  # 当前 → .rollback（回滚后想再切回来用），prev → 主位
  cp -f "$BIN" "$BIN.rollback"
  cp -f "$PREV" "$BIN"
  chmod 755 "$BIN"
  rm -f "$PREV"
  mv -f "$BIN.rollback" "$PREV"
  do_start
  sleep 3
  echo "已回滚到上一版本并重启："
  do_status
}

case "${1:-status}" in
  start)   do_start; do_status ;;
  stop)    do_stop; echo "已停止" ;;
  restart) do_stop; do_start; sleep 2; do_status ;;
  status)  do_status ;;
  rollback) do_rollback ;;
  *) echo "用法: control.sh start|stop|restart|status|rollback"; exit 1 ;;
esac
exit 0
