# Agent2API · KernelSU 模块

> 作者：池鱼 · 基于 [Agent2API](https://github.com/aimod-cc/Agent2API) v3.3.0-beta.6 打包

把 [Agent2API](https://github.com/aimod-cc/Agent2API) v3.3.0-beta.6（多提供商本地网关，Rust 实现）完整移植为 KernelSU 模块：
全部功能（23 个提供商适配器、OpenAI 兼容网关、账号管理、面板、报表）都在一个静态链接的
`agent2api-server` 二进制里，无 Node.js / 无运行时依赖，root 环境直接跑。

## 产物

| 文件 | 说明 |
|---|---|
| `agent2api-ksu-module.zip` | 可刷入的 KernelSU 模块包（8.2 MB，210 个文件） |
| `Agent2API-ksu/` | 模块源目录（打包前体） |

## 模块结构

```
agent2api/
├── module.prop          # id=agent2api, versionCode=300081
├── customize.sh         # 安装脚本：架构检查、权限、ksud 配置默认值、旧实例清理
├── service.sh           # late_start 服务模式拉起网关（开机自启，可关）
├── action.sh            # 管理器 [Action] 按钮：启/停/重启 + 状态输出
├── boot-completed.sh    # 开机完成后兜底补拉
├── uninstall.sh         # 卸载提示（数据目录保留）
├── sepolicy.rule        # ksu 域文件/网络/DNS 策略
├── system.prop          # 空占位（不依赖系统属性）
├── apk/Agent2Login.apk  # 隔离登录器（系统 WebView 容器，安装时 pm install）
├── plugins-bin/          # 插件二进制（aarch64-linux-android）+ version.txt：网关原生优先
│                          #   {plugins}/android-bin/<id>/<版本>/，面板更新插件自动生效
│                          #   （bootstrap 版本精确匹配，无需任何手动动作）
├── sync-plugins.sh       # 插件 Android 二进制落位（service.sh / action.sh 自动调用）
├── bin/agent2api-server # aarch64-linux-android (NDK r29, API 24, rustls 静态 TLS, 11.9 MB)
├── ui/                  # 官方面板静态资源（自托管，浏览器访问 http://127.0.0.1:3065/）
│   └── index.html       # 已接线移动端适配层：css/mobile.css + mobile-columns.js + 抽屉侧栏 DOM
└── webroot/             # KernelSU WebUI 启动器：网关在跑→自动跳转官方面板；没跑→控制台（启停/端口/日志）
```

## 使用

1. KernelSU 管理器 → 模块 → 从本地安装 → 选 zip → 重启（或点 Action 立即启动）。
2. 浏览器打开 `http://127.0.0.1:3065/` → 登录页注册管理员 → 添加上游账号 → 建 API Key。
3. OpenAI 兼容端点：`http://127.0.0.1:3065/v1`（`/chat/completions`、`/models`、`/responses`、`/messages`）。
4. 模块卡片 WebUI：网关运行时自动进入官方面板（移动端专用 UI）；停止时显示控制台（启停、改端口、开机自启、日志）。
5. Action 按钮：运行中→重启，停止→启动。
6. 面板移动端适配（本模块接线）：`css/mobile.css`（895 行适配层）+ `mobile-columns.js`（表格卡片化）
   已接入 `index.html`，并补齐它期望的抽屉 DOM（`#nav-toggle` 开关、顶栏汉堡按钮、`.nav-scrim` 遮罩）。
   手机 <768px 下：侧栏变抽屉、表格拆卡片、body 破版（720px 最小宽）修复；桌面端零影响。
7. 隔离登录器（A2A 登录器 · com.chiyu.a2alogin）：面板发起网页登录时不再跳系统浏览器，
   而是拉起模块自带的独立 WebView 容器（`agent2api://login` intent）——系统 WebView 内核、
   独立 cookie 罐，登录完成自动焚毁 cookie/localStorage/缓存/表单/历史，多账号互不沾染
   （等价于桌面壳 LoginProfile 的一次性数据目录方案）。回调闭环：loopback 重定向直接落回
   网关；自定义协议（office-raccoon:// 等）POST /api/session/login/callback；设备授权轮询类
   （WorkBuddy/Qoder/Cline）无需回调。未装 App / 非 Android 环境自动回退浏览器模式。

## 配置（ksud module config，持久化）

| 键 | 默认 | 说明 |
|---|---|---|
| `port` | `3065` | 网关监听端口 |
| `host` | `127.0.0.1` | 监听地址（改 `0.0.0.0` 开局域网） |
| `autostart` | `1` | 开机自启（`0` 关，仍可 Action/WebUI 手动启） |

数据目录 `/data/adb/agent2api/`：`agent2api.db`（SQLite，WAL）、`account.key`（凭证加密密钥）、`server.log`（滚动 2MB）。卸载模块保留数据，彻底清除 `rm -rf /data/adb/agent2api`。

## 构建（复现）

```bash
# 依赖：rustup target aarch64-linux-android + NDK r29 (aarch64 host tools)
export PATH=<module>/build-ndk:$PATH          # clang wrapper：剥 -landroid
export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER=aarch64-linux-android24-clang-wrap
export CC_aarch64_linux_android=aarch64-linux-android24-clang-wrap
export CXX_aarch64_linux_android=aarch64-linux-android24-clang++-wrap
export AR_aarch64_linux_android=$NDK/toolchains/llvm/prebuilt/linux-aarch64/bin/llvm-ar
cd Agent2API/desktop-tauri/src-tauri
cargo build --release -p agent2api-server --target aarch64-linux-android
# 产物 target/aarch64-linux-android/release/agent2api-server → bin/
```

要点：`-landroid` 必须从链接行剥掉（NDK app 运行时库，root 二进制不链接）；
`-ldl`/`-llog` 保留（bionic 自带，SQLite dlopen 需要）。release profile 用上游的
`lto=true, opt-level="s", strip=true`。

## 已验证（真机 KernelSU 4.2.1 / Android 15 / arm64）

- [x] `ksud module install` 安装成功，customize.sh 输出正常
- [x] action.sh 启动 → `/health` 返回 `{"status":"ok"}`
- [x] 面板 HTML 正常服务（web_shim 注入、静态资源、��录页）
- [x] SQLite 落盘（agent2api.db + WAL）、模块配置读写、override.description 动态描述生效
- [x] ALTCHA 验证码 PoW → 管理员注册 → 登录（双令牌进响应体）→ 创建 API Key（sk-a2a-…）
- [x] `/v1/models` 带 Key 返回 200；`/v1/chat/completions` 走完整选路（无上游账号时 503 + 统计入库，符合预期）
- [x] service.sh / boot-completed.sh / uninstall.sh 语法与逻辑审查通过
- [ ] 重启后的自启链路（service.sh 由 ksud 在 late_start 拉起）未实测——本机用 action.sh 手动验证替代
- [ ] WebUI 在管理器内的渲染（webroot 已就位，ksu.exec 桥按官方库调用）

## 上游环境变量（模块内已设）

`AGENT2API_PROXY_HOME=/data/adb/agent2api`、`AGENT2API_UI_DIR=<MODDIR>/ui`、
`AGENT2API_CAPTCHA_ENABLED=1`、`AGENT2API_SELF_UPDATE=0`（模块内禁用原地更新，升级走重刷 zip）。
其余全部环境变量（23 个提供商各自的 `*_BASE_URL`/`*_TOKEN` 等）可在面板或 service.sh 里按需追加。

## 可靠性与升级（KSU Module 12 起）

| 能力 | 实现 |
|---|---|
| 开机自启 | service.sh（late_start）+ boot-completed.sh 兜底 + ksud 配置 autostart |
| 崩溃自恢复 | supervisor.sh 守护进程常驻：网关异常退出按退避自动重启（3s 起步翻倍封顶 60s；稳定运行 ≥300s 计数归一）；实测 kill -9 后 3s 爬起 |
| 一键回滚 | 升级时旧二进制自动存为 bin/agent2api-server.prev；WebUI「回滚上一版」或 `sh control.sh rollback` 一键切回 |
| 在线升级 | ① 模块级：module.prop 的 updateJson（自行托管 zip 后管理器一键更新）② WebUI「检查上游更新」按钮实时查 GitHub 最新版 |
| DNS 自适应 | 原生 aarch64-linux-android 编译（bionic libc）：DNS 走 Android netd，自动跟随 VPN / 私有 DNS 切换，无需 resolv.conf |
| 为什么不带 glibc 运行时 | 本模块原生交叉编译（bionic），不需要 glibc 兼容层；面板内置自更新保持关闭（AGENT2API_SELF_UPDATE=0），因为官方更新包是 glibc 二进制且会覆盖掉本模块的补丁（手机端登录方式回落 / 插件 android-bin / 隔离登录器接线），升级走重刷模块 zip |

(echo '拒绝在未挂载的客户机路径上执行。客户机 /data 不是手机 /data；请改用 /var/minis/workspace，或用 android-su 访问真实宿主路径。' >&2; false)|stop|restart|status|rollback`

## glibc 运行时模式（KSU Module 13 起，用户选定）

网关改为 aarch64-linux-gnu 二进制 + 模块自带 glibc 运行时（3.0MB：loader/libc/libm/libgcc_s/NSS），
由 supervisor 经 `ld-linux-aarch64.so.1 --library-path glibc/` 拉起。带来的能力：

- **面板自更新（AGENT2API_SELF_UPDATE=1）**：设置 → 软件更新，可直接下载官方版本原地替换
  （官方包就是 glibc 二进制，经同一 loader 运行）。自更新会覆盖本模块的网关侧补丁
  （手机端登录方式回落 / android-bin 插件优先级），但：
  - 插件仍能跑：sync-plugins.sh 把插件包里的 GNU 二进制包一层 loader 壳（幂等，启动前执行）
  - 登录器接线仍生效：patch-ui.sh 每次启动前重放 m.html / mobile.js 的 A2A_LOGIN_OPEN 补丁
  - 想回到补丁版：control.sh rollback（升级时旧二进制自动存 .prev）
- **DNS 自适应（dnsfwd）**：glibc 无 /etc/resolv.conf 时默认查 127.0.0.1:53 —— 模块自带
  dnsfwd（bionic 编译，320KB）在该端口收查询，转发给「当前系统 DNS」（getprop net.dns1/2，
  60s 自适应刷新，兜底 223.5.5.5/119.29.29.29）。VPN / Wi-Fi / 数据网切换自动跟随。
- 进程名注意：经 loader 启动后进程名是 ld-linux-aarch64.so.1，启停/状态统一走 PID 文件
  （control.sh 与 WebUI 已适配），不要用 pidof agent2api-server 判活。

## 参考 agent2api-magisk 采纳的方案（KSU Module 16 起）

- **DNS（文件方案，替代转发器进程）**：构建期把 libc.so.6 里写死的
  `/etc/resolv.conf` / `/etc/nsswitch.conf` / `/etc/gai.conf` 等长改写为
  `/data/a2a/` 下的普通文件（tools/patch-glibc-paths.py），运行期 dns.sh 自适应
  维护：多级采集（dumpsys dnsresolver 按 NetId+接口 → connectivity → DHCP
  属性 → net.dns → 公共兜底）、VPN 下只认隧道 DNS（防泄漏）、gai.conf IPv4
  优先（防双栈半通 30s 超时）、tmp+mv 原子写入。零挂载、零额外进程。
- **插件 PT_INTERP 原地修复（替代包装壳）**：GNU 插件二进制的解释器字符串
(echo '拒绝在未挂载的客户机路径上执行。客户机 /data 不是手机 /data；请改用 /var/minis/workspace，或用 android-su 访问真实宿主路径。' >&2; false)
- **loader --argv0**：进程 cmdline 恢复 agent2api-server（判活走 PID 文件）。
- **守护单实例锁**：mkdir 原子锁 + owner PID 校验，杜绝「多守护打架」
  （部署中断积累多实例、一个占端口其它撞墙重试的事故）。
- **启动前清孤儿**：control.sh start 与 supervisor 首轮都先扫杀残留网关实例。
