#!/system/bin/sh
# ── Agent2API KernelSU 模块 · Action 按钮（管理器卡片）──────────
# 运行中 → 重启；停止 → 启动。输出显示在管理器 Action 结果页。
MODDIR=${0%/*}
echo "── Agent2API 网关 ──"
sh "$MODDIR/control.sh" restart
echo ""
echo "崩溃自恢复：守护进程常驻（supervisor.sh），网关异常退出后自动按退避重启。"
echo "一键回滚：  WebUI 控制台「回滚上一版」按钮，或 sh $MODDIR/control.sh rollback"
