#!/system/bin/sh
# ── Agent2API 模块 · 插件二进制同步（android-bin 落位 + PT_INTERP 修复）──
# 两件事：
#   1. 落位：模块自带的 aarch64-linux-android 插件二进制 →
#      {plugins}/android-bin/<包id>/<版本>/<包id>（网关 bootstrap 原生优先用）
#   2. interp 修复：插件包里的 GNU 二进制 PT_INTERP 原地改写为
#      /data/a2a/ld.so（软链到模块 loader）—— 网关直接 exec，无需包装壳。
#      网关自更新到官方版（无 android-bin 补丁）后，插件靠这层继续跑。
MODDIR=${0%/*}
PLUGINS_DIR=/data/adb/agent2api/plugins
SRC_DIR="$MODDIR/plugins-bin"
VERSION_FILE="$SRC_DIR/version.txt"
. "$MODDIR/plugin-fix.sh"

[ -d "$SRC_DIR" ] || exit 0
VERSION=""
[ -f "$VERSION_FILE" ] && VERSION=$(head -1 "$VERSION_FILE" | tr -d ' \r\n')

loader_link_ensure

# ── 1. android-bin 落位（含权限自愈）────────────────────
stage_one() {
  local id="$1"
  local src="$SRC_DIR/$id"
  [ -f "$src" ] || return 0
  [ -n "$VERSION" ] || return 0
  local dst_dir="$PLUGINS_DIR/android-bin/$id/$VERSION"
  local dst="$dst_dir/$id"
  if [ ! -f "$dst" ] || ! cmp -s "$src" "$dst" 2>/dev/null; then
    mkdir -p "$dst_dir"
    cp -f "$src" "$dst"
  fi
  chmod 755 "$dst" 2>/dev/null
}

stage_one agent2api-providers
stage_one agent2api-web-providers

# ── 2. GNU 插件二进制 PT_INTERP 修复（幂等）────────────────
if [ -d "$PLUGINS_DIR" ] && [ -f "$LOADER_LINK" ]; then
  for pkg in "$PLUGINS_DIR"/*/; do
    case "$pkg" in */android-bin/) continue ;; esac
    for ver in "$pkg"*/; do
      [ -d "$ver/bin" ] || continue
      for f in "$ver"bin/*; do
        [ -f "$f" ] || continue
        case "$f" in *.gnu) continue ;; esac
        _r=$(interp_fix "$f" 2>/dev/null)
        [ "$_r" = "fixed" ] && echo "[plugins] PT_INTERP 已修复: $f"
        chmod 755 "$f" 2>/dev/null
      done
    done
  done
fi
exit 0
