#!/system/bin/sh
# ── Agent2API KernelSU 模块 · 开机自启（late_start 服务模式）──────
# 只做两件事：查配置里的 autostart，然后交给 control.sh（守护进程负责拉起与自恢复）。
MODDIR=${0%/*}
DATA_DIR=/data/adb/agent2api

[ -f "$MODDIR/disable" ] && exit 0
[ -f "$MODDIR/remove" ] && exit 0

AUTOSTART=1
if [ -x /data/adb/ksu/bin/ksud ]; then
  export KSU_MODULE=agent2api
  V=$(/data/adb/ksu/bin/ksud module config get autostart 2>/dev/null) && [ -n "$V" ] && AUTOSTART=$V
fi
[ "$AUTOSTART" = "0" ] && exit 0

sh "$MODDIR/control.sh" start
exit 0
