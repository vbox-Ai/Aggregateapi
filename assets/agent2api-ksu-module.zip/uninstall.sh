#!/system/bin/sh
# ── Agent2API KernelSU 模块 · 卸载脚本 ─────────────────────
# 数据目录 /data/adb/agent2api（数据库/账号凭证/日志）默认保留，
# 用户想清干净就手动删。这里只做提示。
echo "Agent2API 模块已卸载。"
echo "数据目录 /data/adb/agent2api 已保留（数据库、账号凭证、日志）。"
echo "如需彻底清除: rm -rf /data/adb/agent2api"
# 停掉在跑的进程
pidof agent2api-server >/dev/null 2>&1 && killall agent2api-server 2>/dev/null
# 移除隔离登录器 App（模块的一部分，随模块走）
pm uninstall com.chiyu.a2alogin >/dev/null 2>&1
exit 0
