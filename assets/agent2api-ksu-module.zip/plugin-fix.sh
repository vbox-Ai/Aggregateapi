#!/system/bin/sh
# ── Agent2API 模块 · 插件二进制 PT_INTERP 修复（参考 agent2api-magisk）──
# 官方插件包的二进制是桌面 Linux 编的，ELF PT_INTERP 写死
# /lib/ld-linux-aarch64.so.1 —— Android 根分区没有 /lib，execve 报 ENOENT。
# 解法：把 interp 字符串原地改成 /data/a2a/ld.so（软链到模块自带 loader）。
# 原槽位 27 字节（26 + NUL），新串 15 字节，余下补 NUL；phdr/长度/偏移全不动。
# 比包装壳脚本更干净：网关直接 exec，进程树无中间层，stdio/退出码天然直通。

LOADER_LINK=/data/a2a/ld.so

# 读 PT_INTERP 的 <p_offset> <p_filesz>（ELF64：e_phoff@32、e_phentsize@54、
# e_phnum@56；phdr：p_type@0=3、p_offset@8、p_filesz@32）
interp_of() {
  [ -f "$1" ] || return 1
  [ "$(head -c 4 "$1" 2>/dev/null | od -An -tx1 | tr -d ' \n')" = "7f454c46" ] || return 1
  _phoff=$(od -An -tu8 -j32 -N8 "$1" 2>/dev/null | tr -d ' \t\r\n')
  _phes=$(od -An -tu2 -j54 -N2 "$1" 2>/dev/null | tr -d ' \t\r\n')
  _phnum=$(od -An -tu2 -j56 -N2 "$1" 2>/dev/null | tr -d ' \t\r\n')
  case "$_phoff$_phes$_phnum" in ''|*[!0-9]*) return 1 ;; esac
  _i=0
  while [ "$_i" -lt "$_phnum" ]; do
    _off=$((_phoff + _i * _phes))
    _type=$(od -An -tu4 -j"$_off" -N4 "$1" 2>/dev/null | tr -d ' \t\r\n')
    if [ "$_type" = "3" ]; then
      _poff=$(od -An -tu8 -j$((_off + 8)) -N8 "$1" 2>/dev/null | tr -d ' \t\r\n')
      _pfsz=$(od -An -tu8 -j$((_off + 32)) -N8 "$1" 2>/dev/null | tr -d ' \t\r\n')
      printf '%s %s' "$_poff" "$_pfsz"
      return 0
    fi
    _i=$((_i + 1))
  done
  return 1
}

interp_string() {
  _r=$(interp_of "$1" 2>/dev/null) || return 1
  _poff=$(printf '%s' "$_r" | awk '{print $1}')
  _pfsz=$(printf '%s' "$_r" | awk '{print $2}')
  dd if="$1" bs=1 skip="$_poff" count="$_pfsz" 2>/dev/null | tr -d '\000'
}

# 改写 interp → $LOADER_LINK（等长槽位内补 NUL）
# 输出 ok / fixed / static / skip；返回 0 = 可用
interp_fix() {
  _f="$1"
  _cur=$(interp_string "$_f" 2>/dev/null)
  [ -z "$_cur" ] && { echo static; return 0; }        # 静态 ELF（bionic 插件）无需改
  case "$_cur" in
    "$LOADER_LINK") echo ok; return 0 ;;               # 已改过
    /lib/ld-linux-aarch64.so.1|/lib64/ld-linux-aarch64.so.1) ;;
    *) echo skip; return 0 ;;                          # 其它 interp（如 /system/bin/linker64）不动
  esac
  _r=$(interp_of "$_f" 2>/dev/null) || { echo skip; return 0; }
  _poff=$(printf '%s' "$_r" | awk '{print $1}')
  _pfsz=$(printf '%s' "$_r" | awk '{print $2}')
  _new="$LOADER_LINK"
  [ "$_pfsz" -ge $(( ${#_new} + 1 )) ] || { echo skip; return 0; }
  # 原地写：新串 + NUL + NUL 填满槽位
  printf '%s' "$_new" | dd of="$_f" bs=1 seek="$_poff" conv=notrunc 2>/dev/null
  dd if=/dev/zero of="$_f" bs=1 seek=$((_poff + ${#_new})) count=$((_pfsz - ${#_new})) conv=notrunc 2>/dev/null
  _chk=$(interp_string "$_f" 2>/dev/null)
  [ "$_chk" = "$_new" ] && { echo fixed; return 0; }
  echo fail
  return 1
}

# 建 /data/a2a/ld.so 软链（指向模块 loader）
loader_link_ensure() {
  mkdir -p /data/a2a 2>/dev/null
  _target="/data/adb/modules/agent2api/glibc/ld-linux-aarch64.so.1"
  _cur=$(readlink "$LOADER_LINK" 2>/dev/null)
  [ "$_cur" = "$_target" ] && return 0
  rm -f "$LOADER_LINK" 2>/dev/null
  ln -s "$_target" "$LOADER_LINK" 2>/dev/null
  return 0
}
