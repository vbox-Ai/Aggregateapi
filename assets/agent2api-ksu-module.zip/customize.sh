#!/system/bin/sh
# ── Agent2API KernelSU 模块 · 安装脚本 ─────────────────────
# BusyBox ash（ASH_STANDALONE=1）环境；SKIPUNZIP=0 由 customize 决定。
umask 022

# KernelSU 环境标记（Magisk 下 KSU=false，本模块按 KernelSU 设计，但脚本保持双兼容）
KSU_ENV="${KSU:-false}"

# ── 平台检查：只接受 arm64（二进制是 aarch64-linux-android）──────
ARCH=$(uname -m)
if [ "$ARCH" != "aarch64" ]; then
  ui_print "*********************************************************"
  ui_print " 当前架构: $ARCH"
  ui_print " 本模块只带 aarch64 二进制（arm64-v8a 设备）。"
  ui_print " 安装中止。"
  ui_print "*********************************************************"
  abort
fi

# ── 目录布局 ─────────────────────────────────────────────
# MODPATH   = /data/adb/modules_update/agent2api（安装中）
# MODDIR    = 安装后 /data/adb/modules/agent2api
# 数据目录  = /data/adb/agent2api  （数据库/配置/日志，卸载不删，uninstall.sh 里提示）
ui_print "***********************************************"
ui_print " Agent2API Gateway v3.3.0-beta.6"
ui_print " 多提供商本地网关 · KernelSU 模块"
ui_print " by 池鱼"
ui_print "***********************************************"
ui_print ""
ui_print " 二进制: agent2api-server v3.3.0-beta.6 (aarch64-linux-gnu · glibc 运行时 · 面板自更新已开启)"
ui_print " 面板 UI: webroot/ (KernelSU WebUI) + ui/ (自托管面板)"
ui_print ""
ui_print " 安装目录: $MODPATH"
ui_print " 数据目录: /data/adb/agent2api"
ui_print ""

# ── 权限与 SELinux context ──────────────────────────────
# 二进制与脚本统一 0755 root:root；context 由 KernelSU 安装器统一处理，
# 这里只保证执行位。
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/bin/agent2api-server" 0 0 0755
chmod 755 "$MODPATH"/glibc/* 2>/dev/null
set_perm "$MODPATH/bin/agent2api-server.prev" 0 0 0755 2>/dev/null
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/control.sh" 0 0 0755
set_perm "$MODPATH/supervisor.sh" 0 0 0755
set_perm "$MODPATH/boot-completed.sh" 0 0 0755
set_perm "$MODPATH/sync-plugins.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

# webroot 交由 KernelSU 管理器接管（自动设权限与 context），不要动。

# ── 数据目录预建（首次安装即就绪，服务起来直接用）────────────
mkdir -p /data/adb/agent2api
chmod 700 /data/adb/agent2api
chown root:root /data/adb/agent2api 2>/dev/null

# ── 旧实例清理：安装/升级时停掉在跑的旧进程（守护也一起停）──────
if pidof agent2api-server >/dev/null 2>&1; then
  ui_print " 停止运行中的旧实例..."
  touch /data/adb/agent2api/stop.flag
  killall agent2api-server 2>/dev/null
  sleep 2
  pidof agent2api-server >/dev/null 2>&1 && killall -9 agent2api-server 2>/dev/null
fi

# ── 一键回滚：把旧版二进制存为 .prev（control.sh rollback 的回滚目标）──
OLD_BIN=/data/adb/modules/agent2api/bin/agent2api-server
if [ -f "$OLD_BIN" ] && ! cmp -s "$OLD_BIN" "$MODPATH/bin/agent2api-server" 2>/dev/null; then
  cp -f "$OLD_BIN" "$MODPATH/bin/agent2api-server.prev"
  chmod 755 "$MODPATH/bin/agent2api-server.prev"
  ui_print " 已保留旧版二进制为 .prev（WebUI「回滚上一版」可一键切回）"
fi

# ── 模块配置默认值（ksud module config，持久化）──────────────
# 仅在键不存在时写入默认，尊重用户已改过的值。
if command -v ksud >/dev/null 2>&1; then
  KSUD_BIN=$(command -v ksud)
elif [ -x /data/adb/ksu/bin/ksud ]; then
  KSUD_BIN=/data/adb/ksu/bin/ksud
else
  KSUD_BIN=""
fi
if [ -n "$KSUD_BIN" ]; then
  export KSU_MODULE=agent2api
  $KSUD_BIN module config get port >/dev/null 2>&1 || $KSUD_BIN module config set port 3065
  $KSUD_BIN module config get host >/dev/null 2>&1 || $KSUD_BIN module config set host 127.0.0.1
  $KSUD_BIN module config get autostart >/dev/null 2>&1 || $KSUD_BIN module config set autostart 1
  ui_print " 模块配置: port=3065 host=127.0.0.1 autostart=1"
else
  ui_print " (未找到 ksud，配置默认值将在 service.sh 里落盘到 data 目录)"
fi

# ── 登录器 App 安装：隔离登录容器（系统 WebView，独立 cookie 罐，登完即焚）──
# pm 装到 /data/app（用户 0），模块卸载时 uninstall.sh 里移除。
# /sdcard 是 fuse context，system_server 读不了 —— 先拷到 /data/local/tmp 再装。
if [ -f "$MODPATH/apk/Agent2Login.apk" ]; then
  cp "$MODPATH/apk/Agent2Login.apk" /data/local/tmp/Agent2Login.apk
  chmod 644 /data/local/tmp/Agent2Login.apk
  if pm install -r /data/local/tmp/Agent2Login.apk >/dev/null 2>&1; then
    ui_print " 隔离登录器: 已安装（A2A 登录器 · com.chiyu.a2alogin）"
    ui_print "   面板网页登录将使用独立 WebView 容器，多账号互不沾染"
  else
    ui_print " ⚠ 隔离登录器安装失败（不影响网关本体），登录将回退浏览器模式"
  fi
  rm -f /data/local/tmp/Agent2Login.apk
fi

ui_print ""
ui_print " 安装完成。重启后 service.sh 拉起网关；"
ui_print " 或在管理器里点模块卡片 [Action] 立即启动。"
ui_print " 面板地址: http://127.0.0.1:3065/"
ui_print "***********************************************"
