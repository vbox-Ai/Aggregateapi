#!/system/bin/sh
# ── Agent2API 模块 · DNS 自适应（glibc 配置文件方案）────────────────
# 参考 agent2api-magisk 的 dns.sh：libc 已在构建期把 /etc/resolv.conf 等路径
# 等长改写为 /data/a2a/ 下的普通文件，这里负责自适应维护它们：
#   resolv   —— 多级采集当前系统 DNS（dumpsys dnsresolver → connectivity →
#               DHCP 属性 → net.dns 属性 → 公共 DNS 兜底），VPN 下只认隧道
#   nsswitch —— hosts: files dns（files 读不到 /etc/hosts = ENOENT 无害）
#   gai      —— IPv4 优先（手机双栈常只通一半，glibc 默认先试 IPv6 会 30s 超时）
# 写入全部走 tmp + mv 原子替换，服务端解析途中不会读到半截文件。

A2A_LIVE=/data/a2a
DNSFILE="$A2A_LIVE/resolv"
NSSFILE="$A2A_LIVE/nsswitch"
GAIFILE="$A2A_LIVE/gai"
DNS_CACHE="/data/adb/agent2api/dns.last"
DNS_ACTIVE_CACHE="/data/adb/agent2api/dns-iface"
DNS_VPN_CACHE="/data/adb/agent2api/dns-vpn"
DNS_STATIC="223.5.5.5 119.29.29.29"

valid_ipv4() {
  case "$1" in
    ''|*[!0-9.]*|.*|*.|*..*) return 1 ;;
  esac
  [ "$(printf '%s' "$1" | tr -dc '.' | wc -c | tr -d ' ')" = "3" ] || return 1
  _oldifs="$IFS"; IFS=.
  set -- $1
  IFS="$_oldifs"
  [ "$#" = "4" ] || return 1
  for _n in "$@"; do
    case "$_n" in ''|*[!0-9]*) return 1 ;; esac
    [ "$_n" -le 255 ] 2>/dev/null || return 1
  done
  return 0
}

dns_default_iface() {
  _di=$(ip route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1);exit}}')
  [ -n "$_di" ] || _di=$(ip route 2>/dev/null | awk '/^default /{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1);exit}}')
  printf '%s' "$_di"
}

dns_vpn_active() {
  case "$(dns_default_iface 2>/dev/null)" in tun*|ppp*|wg*) return 0 ;; esac
  command -v dumpsys >/dev/null 2>&1 || return 1
  dumpsys connectivity 2>/dev/null | grep -Eiq 'VPN|type[ =:]+VPN|TRANSPORT_VPN'
}

dns_active_netid() {
  dumpsys connectivity 2>/dev/null | sed -n 's/^Active default network:[[:space:]]*//p' | head -n 1 | tr -dc '0-9'
}

dns_local_addrs() {
  ip -4 addr 2>/dev/null | awk '/inet /{sub(/\/.*/,"",$2); print $2}'
}

dns_ip_usable() {
  valid_ipv4 "$1" || return 1
  case "$1" in
    0.*|127.*|169.254.*|255.255.255.255) return 1 ;;
    224.*|23[0-9].*|24[0-9].*|25[0-5].*) return 1 ;;
  esac
  for _lu in $(dns_local_addrs 2>/dev/null); do
    [ "$_lu" = "$1" ] && return 1
  done
  return 0
}

# 首选：dumpsys dnsresolver 按 NetId 分块，接口对上才取（VPN 下只认隧道块）
dns_from_resolver() {
  dumpsys dnsresolver 2>/dev/null | awk -v want_if="$1" -v want_net="$2" '
    function flush() {
      if (ips != "") {
        hit = 0
        if (want_if != "" && ifc != "") {
          n = split(ifc, a, ",")
          for (i = 1; i <= n; i++) { gsub(/[ \t]/, "", a[i]); if (a[i] == want_if) hit = 1 }
        }
        if (hit == 0 && want_net != "" && net == want_net) hit = 1
        if (hit == 1) {
          n = split(ips, b, " ")
          for (i = 1; i <= n; i++) if (b[i] != "") print b[i]
        }
      }
      ips = ""; ifc = ""; net = ""; inlist = 0
    }
    /^NetId: / { flush(); net = $2; next }
    /DNS servers:/ { inlist = 1; next }
    inlist == 1 && $1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ { ips = ips " " $1; next }
    /Interface names:/ {
      inlist = 0
      s = $0; sub(/.*Interface names:[ \t]*\[/, "", s); sub(/\].*/, "", s); ifc = s
      flush()
      next
    }
    END { flush() }
  '
}

# 次选：dumpsys connectivity 的 NetworkAgentInfo（InterfaceName + DnsAddresses 同块）
dns_from_connectivity() {
  dumpsys connectivity 2>/dev/null | awk -v want_if="$1" '
    function emit() {
      if (ifc == "" || ips == "") return
      if (want_if != "" && ifc != want_if) return
      n = split(ips, a, /[][,\/ \t]+/)
      for (i = 1; i <= n; i++) if (a[i] ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) print a[i]
    }
    /NetworkAgentInfo\{/ { ifc = ""; ips = "" }
    ifc == "" && match($0, /InterfaceName:[ \t]*[^ \t,\]]+/) {
      s = substr($0, RSTART, RLENGTH); sub(/InterfaceName:[ \t]*/, "", s); ifc = s
    }
    match($0, /DnsAddresses:[ \t]*\[[^]]*\]/) {
      s = substr($0, RSTART, RLENGTH); sub(/DnsAddresses:[ \t]*\[/, "", s); sub(/\]$/, "", s); ips = s
      emit()
    }
  '
}

dns_collect_system() {
  _found=""
  _iface=$(dns_default_iface 2>/dev/null)
  _netid=$(dns_active_netid 2>/dev/null)
  _vpn=0
  case "$_iface" in tun*|ppp*|wg*) _vpn=1 ;; esac

  if [ "$_vpn" = "1" ]; then
    # VPN 出口：只认隧道自己的解析器，绝不回退物理网卡（防 DNS 泄漏）
    _found=$(dns_from_resolver "$_iface" "" 2>/dev/null)
  else
    _found=$(dns_from_resolver "$_iface" "$_netid" 2>/dev/null)
    [ -z "$_found" ] && _found=$(dns_from_connectivity "$_iface" 2>/dev/null)
    if [ -z "$_found" ] && [ -n "$_iface" ]; then
      for _k in dns1 dns2; do
        _v=$(getprop "dhcp.$_iface.$_k" 2>/dev/null)
        [ -n "$_v" ] && _found="$_found $_v"
      done
    fi
    [ -z "$_found" ] && for _k in net.dns1 net.dns2; do
      _v=$(getprop "$_k" 2>/dev/null)
      [ -n "$_v" ] && _found="$_found $_v"
    done
  fi

  if [ -z "$_found" ] && [ "$_vpn" = "1" ]; then
    # 隧道没暴露 DNS（透明代理类）：公共解析器走默认路由进隧道
    _found="$DNS_STATIC"
    echo "[dns] VPN 出口未暴露 DNS，改用公共解析器经隧道" >> "$SUPLOG" 2>/dev/null
  fi

  for _s in $_found; do
    dns_ip_usable "$_s" || continue
    printf 'nameserver %s\n' "$_s"
  done
}

dns_write() {
  _tmp="/data/adb/agent2api/.resolv.$$"
  : >"$_tmp" 2>/dev/null || return 1
  dns_collect_system >>"$_tmp" 2>/dev/null
  # 空结果：保留最后可用配置，不跳公共 DNS（网络切换瞬间很常见）
  if ! grep -q '^nameserver [0-9]' "$_tmp" 2>/dev/null; then
    if [ -s "$DNS_CACHE" ] && grep -q '^nameserver [0-9]' "$DNS_CACHE" 2>/dev/null; then
      rm -f "$_tmp"
      return 0
    fi
    for _s in $DNS_STATIC; do printf 'nameserver %s\n' "$_s" >>"$_tmp"; done
  fi
  {
    printf '# generated by agent2api-ksu %s\n' "$(date '+%F %T' 2>/dev/null)"
    grep '^nameserver' "$_tmp" | awk '!seen[$2]++' | head -n 8
    printf 'options timeout:2 attempts:2 single-request-reopen\n'
  } > "${_tmp}.final" 2>/dev/null || { rm -f "$_tmp"; return 1; }
  mkdir -p "$A2A_LIVE" 2>/dev/null
  cp -f "${_tmp}.final" "$DNSFILE.new" 2>/dev/null \
    && chmod 644 "$DNSFILE.new" 2>/dev/null \
    && mv -f "$DNSFILE.new" "$DNSFILE" 2>/dev/null \
    || { rm -f "$_tmp" "${_tmp}.final"; return 1; }
  cp -f "${_tmp}.final" "$DNS_CACHE" 2>/dev/null
  rm -f "$_tmp" "${_tmp}.final" 2>/dev/null
  _iface=$(dns_default_iface 2>/dev/null)
  printf '%s\n' "${_iface:-unknown}" > "$DNS_ACTIVE_CACHE" 2>/dev/null
  dns_vpn_active; printf '%s\n' "$?" > "$DNS_VPN_CACHE" 2>/dev/null
  _got=$(grep -m1 '^nameserver' "$DNSFILE" 2>/dev/null | awk '{print $2}')
  echo "[dns] 已更新 iface=${_iface:-?} 首选=${_got:-none}" >> "$SUPLOG" 2>/dev/null
  return 0
}

nss_apply() {
  mkdir -p "$A2A_LIVE" 2>/dev/null
  printf 'hosts: files dns\nnetworks: files\n' > "$NSSFILE.new" 2>/dev/null || return 1
  chmod 644 "$NSSFILE.new" 2>/dev/null
  mv -f "$NSSFILE.new" "$NSSFILE" 2>/dev/null || return 1
  return 0
}

gai_apply() {
  mkdir -p "$A2A_LIVE" 2>/dev/null
  printf 'precedence ::ffff:0:0/96  100\n' > "$GAIFILE.new" 2>/dev/null || return 1
  chmod 644 "$GAIFILE.new" 2>/dev/null
  mv -f "$GAIFILE.new" "$GAIFILE" 2>/dev/null || return 1
  return 0
}

dns_bootstrap() {
  mkdir -p "$A2A_LIVE" 2>/dev/null
  chmod 755 "$A2A_LIVE" 2>/dev/null
  dns_write
  nss_apply
  gai_apply
}

# 只在系统 DNS / 接口 / VPN 状态变化时才重写（守护进程周期调用）
dns_refresh_if_changed() {
  _a=$(grep '^nameserver' "$DNS_CACHE" 2>/dev/null | head -2 | awk '{print $2}' | tr '\n' ' ')
  _now=$(dns_collect_system 2>/dev/null | grep '^nameserver' | head -2 | awk '{print $2}' | tr '\n' ' ')
  [ -n "$_now" ] || return 0
  _old_iface=$(cat "$DNS_ACTIVE_CACHE" 2>/dev/null)
  _new_iface=$(dns_default_iface 2>/dev/null)
  _old_vpn=$(cat "$DNS_VPN_CACHE" 2>/dev/null)
  dns_vpn_active; _new_vpn=$?
  [ "$_a" = "$_now" ] && [ "$_old_iface" = "${_new_iface:-unknown}" ] && [ "$_old_vpn" = "$_new_vpn" ] && return 0
  echo "[dns] 网络变化 iface=${_old_iface:-?}->${_new_iface:-?} vpn=$_old_vpn->$_new_vpn" >> "$SUPLOG" 2>/dev/null
  dns_write
}
