#!/system/bin/sh
# ── Agent2API 模块 · UI 补丁重放（自更新后自动恢复登录器接线）──────
# 面板「软件更新」会整体替换 ui/ 目录，把本模块对 m.html / mobile.js 的
# 隔离登录器接线冲掉。本脚本在每次网关启动前幂等重放这两个补丁：
#   1. mobile.js：「打开官方授权页」改走 A2A_LOGIN_OPEN
#   2. m.html：注入 A2A_LOGIN_OPEN 定义（三重拉起：ksu.exec / intent / 浏览器）
# 幂等：已打过补丁（能搜到标记）就跳过，不重复注入。
MODDIR=${0%/*}
UI="$MODDIR/ui"
M="$UI/m.html"
JS="$UI/m/mobile.js"
TMP=/data/adb/agent2api/.patch-ui.tmp

# ── 1. mobile.js：改调用点（v2：传 state 给登录器——Cookie 抓取型回调需要）──
if [ -f "$JS" ] && grep -q 'window.open(\$.url,"_blank","noopener,noreferrer")' "$JS" 2>/dev/null; then
  sed -i 's|window.open(\$.url,"_blank","noopener,noreferrer")|window.A2A_LOGIN_OPEN?window.A2A_LOGIN_OPEN(\$.url,\$.state):window.open(\$.url,"_blank","noopener,noreferrer")|' "$JS"
fi
# v1→v2 升级：已打过旧补丁（只传 url）的补上 state 参数
if [ -f "$JS" ] && grep -q 'window.A2A_LOGIN_OPEN(\$.url)' "$JS" 2>/dev/null && ! grep -q 'window.A2A_LOGIN_OPEN(\$.url,\$.state)' "$JS" 2>/dev/null; then
  sed -i 's|window.A2A_LOGIN_OPEN(\$.url)|window.A2A_LOGIN_OPEN(\$.url,\$.state)|' "$JS"
fi

# ── 2. m.html：注入定义脚本（sed r 从文件读片段，免转义）────────
# v4：state 捕获兜底 —— 拦截 fetch 捕获 login/start 响应里的 state，
# 即使 PWA 的 mobile.js 还是旧缓存（没传 state 参数），登录器也能拿到。
# m.html 是 network-first（每次打开都拿最新），所以这个修复立即生效，
# 不需要用户重开两次 PWA。
# 幂等：检查 stateCapture（v4 标记）；旧版先删再注。
if [ -f "$M" ] && ! grep -q 'capturedProvider' "$M" 2>/dev/null; then
  # 删旧版注入（v1/v2 脚本紧跟 <body>）
  if grep -q 'A2A_LOGIN_OPEN' "$M" 2>/dev/null; then
    sed -i '/<body>/,/<\/script>/{/<body>/!/{/<\/script>/!d}; /<\/script>/d}' "$M" 2>/dev/null
  fi
  cat > "$TMP" <<'BLOCK'
<script>
(function () {
  // stateCapture：拦截 fetch，捕获 login/start 响应里的 state ——
  // 旧缓存 mobile.js 调 A2A_LOGIN_OPEN(url) 不带 state 时用它兜底
  var capturedState = '';
  var capturedProvider = '';
  try {
    var origFetch = window.fetch;
    window.fetch = function (input, init) {
      var promise = origFetch.apply(this, arguments);
      try {
        var u = typeof input === 'string' ? input : (input && input.url) || '';
        if (u.indexOf('/api/session/login/start') >= 0) {
          // 捕获 provider（请求体里）——登录器直接加账号时要用
          try {
            var b = init && init.body;
            if (typeof b === 'string') {
              var pd = JSON.parse(b);
              if (pd && pd.provider) capturedProvider = String(pd.provider);
            }
          } catch (e) { }
          promise.then(function (resp) {
            try {
              resp.clone().json().then(function (data) {
                var st = data && ((data.data && data.data.state) || data.state);
                if (st) capturedState = String(st);
              });
            } catch (e) { }
          });
        }
      } catch (e) { }
      return promise;
    };
  } catch (e) { }
  function fireIntent(intent) {
    if (window.ksu && typeof window.ksu.exec === 'function') {
      try {
        var cb = 'a2a_cb_' + Date.now();
        window[cb] = function () { delete window[cb]; };
        window.ksu.exec("am start -a android.intent.action.VIEW -d '" + intent + "'", '{}', cb);
        return true;
      } catch (e) { }
    }
    try { window.location.href = intent; return true; } catch (e) { return false; }
  }
  function panelToken() {
    try {
      // 方式1：按 activeServer 的 id 读（多服务器形态）
      var sid = localStorage.getItem('agent2api.activeServer') || '';
      if (sid) {
        var auth = JSON.parse(localStorage.getItem('agent2api.panelAuth.' + sid) || 'null');
        if (auth && auth.access) return String(auth.access);
      }
      // 方式2：panelAuth.origin（单服务器/默认形态——实测 PWA 存这里）
      auth = JSON.parse(localStorage.getItem('agent2api.panelAuth.origin') || 'null');
      if (auth && auth.access) return String(auth.access);
      // 方式3：遍历所有 agent2api.panelAuth.* 键兜底
      for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);
        if (key && key.indexOf('agent2api.panelAuth.') === 0) {
          var val = JSON.parse(localStorage.getItem(key) || 'null');
          if (val && val.access) return String(val.access);
        }
      }
      return '';
    } catch (e) { return ''; }
  }
  // stateForward + stateCapture 兜底：优先用调用方传的 state（新版 mobile.js），
  // 没传就用 fetch 拦截捕获的（旧缓存 mobile.js 也能工作）
  window.A2A_LOGIN_OPEN = function (url, state) {
    if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) return;
    var st = state || capturedState || '';
    capturedState = ''; // 一次性：用掉就清，防止串到下一轮
    var ua = String(navigator.userAgent || '');
    if (ua.indexOf('Android') >= 0) {
      var origin = String(window.location.origin || '');
      var intent = 'agent2api://login?gateway=' + encodeURIComponent(origin)
        + '&token=' + encodeURIComponent(panelToken())
        + '&state=' + encodeURIComponent(st)
        + '&provider=' + encodeURIComponent(capturedProvider || '')
        + '&url=' + encodeURIComponent(url);
      if (fireIntent(intent)) return;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  };
})();
</script>
BLOCK
  sed -i "/<body>/r $TMP" "$M"
  rm -f "$TMP"
fi

# ── 3. sw.js：内容指纹缓存戳 + 立即激活 ──────────────────────
# 面板自更新换掉 ui/ 后，SW 缓存里还是旧构建（新 m.html + 旧 JS/CSS =
# 布局错乱图标错位）。把 CACHE 戳改成外壳文件的内容指纹：ui 一变 → 戳变
# → SW 重装 → 缓存重建；skipWaiting 让新 SW 立即接管，无需用户找更新按钮。
SW="$UI/sw.js"
if [ -f "$SW" ]; then
  _stamp=$(cat "$M" "$JS" "$UI/m/mobile.css" 2>/dev/null | md5sum | cut -c1-12)
  sed -i "s|const CACHE = '[^']*'|const CACHE = 'agent2api-mobile-$_stamp'|" "$SW"
  sed -i "s|// 不在这里 skipWaiting.*|self.skipWaiting()|" "$SW"
fi

# ── 4. mobile.css：窄屏高度钳制修复（官方 h-[30px] !important bug）──
# 两处同类 bug：Tailwind h-[30px]（@layer utilities 带 !important）把 JS 内联
# 多行布局的按钮钳在 30px → 内容溢出、行间重叠。非 layer 规则的 !important
# 赢过 layer 内的 !important，两条选择器各解除一处。幂等：有标记就跳过。
CSS="$UI/m/mobile.css"
_css_changed=0
if [ -f "$CSS" ]; then
  # 4a. 「更多」页竖排网格格子（图标上文字下，内容 ≈75px）
  if ! grep -q 'a2a-grid-height-fix' "$CSS" 2>/dev/null; then
    cat >> "$CSS" <<'FIX'
/* a2a-grid-height-fix: 竖排网格格子解除 30px 高度钳制（模块补丁，勿删） */
[data-slot="button"][style*="flex-direction: column"] { height: auto !important; }
FIX
    _css_changed=1
  fi
  # 4b. 请求日志/账号等列表行（JS 内联 display:block 的多行卡片，内容 ≈120-160px）
  if ! grep -q 'a2a-listrow-height-fix' "$CSS" 2>/dev/null; then
    cat >> "$CSS" <<'FIX'
/* a2a-listrow-height-fix: 列表多行卡片解除 30px 高度钳制（模块补丁，勿删） */
[data-slot="button"][style*="display: block"] { height: auto !important; }
FIX
    _css_changed=1
  fi
fi
# CSS 变了 → 缓存戳要跟着变（重算一次，SW 自动重装修复）
if [ "$_css_changed" = "1" ] && [ -f "$SW" ]; then
  _stamp=$(cat "$M" "$JS" "$CSS" 2>/dev/null | md5sum | cut -c1-12)
  sed -i "s|const CACHE = '[^']*'|const CACHE = 'agent2api-mobile-$_stamp'|" "$SW"
fi

# ── 5. mobile.js：数字单位改国际制（K/M/B 替代 万/亿）────────────
# 报表页的 Token 数格式化：官方按语言切万/亿（中文）或 k/M（英文），
# 用户要求统一用 K/M/B。两处格式化函数都改。
# 幂等标记：a2a-numfmt-fix（不能用「 亿」做标记——ms 函数的 zh-Hant
# 回落字符串 "億":"亿" 里永远含简体「亿」，会导致每次重启都重复追加）。
if [ -f "$JS" ] && ! grep -q 'a2a-numfmt-fix' "$JS" 2>/dev/null; then
  # 5a. dc 函数（简版格式化）：万/亿 → K/M/B
  sed -i 's|s>=1e8?`${(e/1e8).toFixed(s>=1e9?0:2)} 亿`:s>=1e4?`${(e/1e4).toFixed(s>=1e6?0:1)} 万`:String(Math.round(e))|s>=1e9?`${(e/1e9).toFixed(2)}B`:s>=1e6?`${(e/1e6).toFixed(s>=1e7?0:1)}M`:s>=1e3?`${(e/1e3).toFixed(s>=1e4?0:1)}K`:String(Math.round(e))|' "$JS"
  # 5b. ms 函数（语言感知格式化）：禁用中文分支，统一走国际制
  sed -i 's|l=Dl().startsWith("zh")|l=false|' "$JS"
  # 5c. ms 函数：补 B 档位（注意：sed 替换文本里的 & 是特殊字符——
  #     表示「整个匹配模式」，必须转义为 \& 才是字面量）
  sed -i 's|if(!l&&a>=1e6)return`${(s/1e6).toFixed(1)}M|if(!l\&\&a>=1e9)return`${(s/1e9).toFixed(2)}B`;if(!l\&\&a>=1e6)return`${(s/1e6).toFixed(1)}M|' "$JS"
  # 5d. 打幂等标记（追加到文件末尾的注释，不影响执行）
  printf '/*a2a-numfmt-fix*/\n' >> "$JS"
fi
exit 0
