/* Agent2API KernelSU WebUI · 启动器 + 控制台
 * 正常路径：网关在跑 → 直接跳转官方面板（专用移动端 UI，同源运行，
 *           cookie/登录/全部功能原生，无跨源问题）
 * 网关没跑：显示控制台（启动/停止/设置/日志），起来后自动进面板 */
(() => {
  const $ = (id) => document.getElementById(id);
  const HAS_KSU = typeof window.ksu !== 'undefined' && typeof window.ksu.exec === 'function';
  const KSUD = '/data/adb/ksu/bin/ksud';
  const BB = '/data/adb/ksu/bin/busybox';
  const DATA = '/data/adb/agent2api';
  const MODDIR = '/data/adb/modules/agent2api';

  let PORT = '3065', HOST = '127.0.0.1';
  let pollTimer = null, statusTimer = null;

  async function sh(cmd) {
    if (!HAS_KSU) return { errno: 1, stdout: '', stderr: 'no ksu bridge' };
    return new Promise((resolve) => {
      const cb = `cb_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
      window[cb] = (errno, stdout, stderr) => { delete window[cb]; resolve({ errno, stdout: stdout || '', stderr: stderr || '' }); };
      try { window.ksu.exec(cmd, '{}', cb); }
      catch (e) { delete window[cb]; resolve({ errno: 1, stdout: '', stderr: String(e) }); }
    });
  }
  const toast = (m) => { if (HAS_KSU && window.ksu.toast) { try { window.ksu.toast(m); } catch {} } };

  async function cfgGet(key) {
    const r = await sh(`export KSU_MODULE=agent2api; ${KSUD} module config get ${key} 2>/dev/null`);
    return r.errno === 0 ? r.stdout.trim() : '';
  }
  async function cfgSet(key, val) {
    return sh(`export KSU_MODULE=agent2api; ${KSUD} module config set ${key} "${val}"`);
  }

  async function healthy(port) {
    const r = await sh(`${BB} wget -qO- http://127.0.0.1:${port}/health 2>/dev/null`);
    return (r.stdout || '').includes('ok');
  }
  const panelUrl = () => `http://127.0.0.1:${PORT}/m.html`;
  const desktopUrl = () => `http://127.0.0.1:${PORT}/`;
  const goPanel = () => { location.href = panelUrl(); };
  const goDesktop = () => { location.href = desktopUrl(); };

  function show(which) {
    $('launch').classList.toggle('hidden', which !== 'launch');
    $('console').classList.toggle('hidden', which !== 'console');
    if (which === 'console') {
      if (!statusTimer) statusTimer = setInterval(refreshStatus, 15000);
    } else if (statusTimer) { clearInterval(statusTimer); statusTimer = null; }
  }

  /* 入口：直接进控制台（启停/回滚/日志/设置）；面板由用户点「打开面板」自行进入 */
  async function enter() {
    $('launchAddr').textContent = panelUrl();
    show('console');
    refreshStatus();
    loadLog();
  }

  function setStatus(cls, text) {
    $('status').innerHTML = `<span class="dot ${cls}"></span><span>${text}</span>`;
  }

  async function refreshStatus() {
    setStatus('wait', '检测中…');
    // 健康检查优先（PID 文件可能被竞态删掉，但网关活得好好的——显示层不能误报「已停止」）
    const r = await sh(`cat ${DATA}/agent2api.pid 2>/dev/null; echo ---; ${BB} wget -qO- http://127.0.0.1:${PORT}/health 2>/dev/null; echo ---; grep '^version=' ${MODDIR}/module.prop 2>/dev/null | head -1 | cut -d= -f2; echo ---; ${BB} wget -qO- http://127.0.0.1:${PORT}/health 2>/dev/null | grep -q '"ok"' && echo alive || echo dead`);
    const [pid, health, ver, alive] = r.stdout.split('---').map(s => s.trim());
    const running = alive === 'alive';
    $('pid').textContent = running ? pid : '未运行';
    $('listen').textContent = `${HOST}:${PORT}`;
    $('health').textContent = health ? health.slice(0, 60) : '—';
    $('ver').textContent = ver || 'v3.0.8';
    $('apiBase').textContent = `http://127.0.0.1:${PORT}/v1`;
    if (running && health.includes('ok')) setStatus('on', '运行中');
    else if (running) setStatus('wait', '启动中');
    else setStatus('off', '已停止');
  }

  async function loadConfig() {
    const [port, host, autostart] = await Promise.all([cfgGet('port'), cfgGet('host'), cfgGet('autostart')]);
    if (port) { PORT = port; $('cfgPort').value = port; }
    if (host) { HOST = host; $('cfgHost').value = host; }
    if (autostart) $('cfgAutostart').value = autostart;
  }

  async function loadLog() {
    const r = await sh(`tail -n 60 ${DATA}/server.log 2>/dev/null || echo "(暂无日志)"`);
    $('log').textContent = r.stdout || r.stderr || '(暂无日志)';
  }

  /* 启动后轮询健康，通了自动进面板 */
  function waitUpThenEnter(timeoutS) {
    if (pollTimer) clearInterval(pollTimer);
    const t0 = Date.now();
    pollTimer = setInterval(async () => {
      if (await healthy(PORT)) {
        clearInterval(pollTimer); pollTimer = null;
        toast('网关已就绪');
        enter();
      } else if (Date.now() - t0 > timeoutS * 1000) {
        clearInterval(pollTimer); pollTimer = null;
        refreshStatus();
        loadLog();
      }
    }, 2000);
  }

  async function doStart() {
    toast('正在启动…');
    await sh(`sh ${MODDIR}/control.sh start >/dev/null 2>&1`);
    waitUpThenEnter(20);
  }
  async function doStop() {
    toast('正在停止…');
    await sh(`sh ${MODDIR}/control.sh stop >/dev/null 2>&1`);
    setTimeout(refreshStatus, 1500);
  }
  async function doRestart() {
    toast('正在重启…');
    await sh(`sh ${MODDIR}/action.sh >/dev/null 2>&1`);
    waitUpThenEnter(20);
  }
  async function doRollback() {
    toast('正在回滚到上一版…');
    const r = await sh(`sh ${MODDIR}/control.sh rollback 2>&1`);
    const first = (r.stdout || '').split('\n').filter(l => l.trim())[0] || '回滚完成';
    toast(first);
    waitUpThenEnter(20);
  }
  async function doCheckUpdate() {
    toast('正在查询上游版本…');
    const r = await sh(`curl -s -m 15 https://api.github.com/repos/aimod-cc/Agent2API/releases 2>/dev/null | grep -m1 '"tag_name"' | sed 's/.*"tag_name": "//;s/"//'`);
    const latest = (r.stdout || '').trim();
    $('upstream').textContent = latest || '查询失败';
    toast(latest ? `上游最新：${latest}` : '查询失败');
  }
  async function doSave() {
    const port = ($('cfgPort').value || '3065').trim();
    const host = $('cfgHost').value;
    const autostart = $('cfgAutostart').value;
    if (!/^\d+$/.test(port) || +port < 1 || +port > 65535) { toast('端口无效'); return; }
    await cfgSet('port', port);
    await cfgSet('host', host);
    await cfgSet('autostart', autostart);
    PORT = port; HOST = host;
    toast('已保存，正在重启网关…');
    await sh(`sh ${MODDIR}/action.sh >/dev/null 2>&1`);
    waitUpThenEnter(20);
  }

  document.addEventListener('DOMContentLoaded', async () => {
    try {
      if (!HAS_KSU) {
        setStatus('off', '无 KernelSU 环境');
        $('log').textContent = '此页面需在 KernelSU 管理器的 WebUI 中打开。';
      }
      // 空安全绑定：元素缺失（新旧 HTML/JS 混装）时跳过该项，绝不炸整页
      const bind = (id, fn) => { const el = $(id); if (el) el.onclick = fn; };
      bind('btnEnter', goPanel);
      bind('btnStart', doStart);
      bind('btnStop', doStop);
      bind('btnRestart', doRestart);
      bind('btnPanel', goPanel);
      bind('btnDesktop', goDesktop);
      bind('btnSave', doSave);
      bind('btnLog', loadLog);
      bind('btnRollback', doRollback);
      bind('btnUpdate', doCheckUpdate);
      await loadConfig();
      await enter();
    } catch (e) {
      // 初始化异常要可见，不能让页面静默变成「按钮全死」
      try { $('log').textContent = '控制台初始化异常：' + (e && e.message ? e.message : String(e)); } catch {}
    }
  });
})();
