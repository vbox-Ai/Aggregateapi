#!/system/bin/sh
# ── Agent2API KernelSU 模块 · 守护进程（崩溃自恢复 + glibc + DNS 自适应）──
# 常驻循环：DNS 自适应 → 拉起网关（glibc loader + --argv0）→ 崩了退避重启。
# 退避：3s 起步翻倍封顶 60s；稳定 ≥300s 计数归一。
MODDIR=${0%/*}
DATA_DIR=/data/adb/agent2api
BIN="$MODDIR/bin/agent2api-server"
GLIBC="$MODDIR/glibc"
LOADER="$GLIBC/ld-linux-aarch64.so.1"
LOG="$DATA_DIR/server.log"
PIDFILE="$DATA_DIR/agent2api.pid"
SUPPID="$DATA_DIR/supervisor.pid"
SUPLOG="$LOG"
STOPFLAG="$DATA_DIR/stop.flag"
KSUD=/data/adb/ksu/bin/ksud

. "$MODDIR/dns.sh"

# ── 配置读取 ─────────────────────────────────────────────
PORT=3065
HOST=127.0.0.1
if [ -x "$KSUD" ]; then
  export KSU_MODULE=agent2api
  V=$($KSUD module config get port 2>/dev/null) && [ -n "$V" ] && PORT=$V
  V=$($KSUD module config get host 2>/dev/null) && [ -n "$V" ] && HOST=$V
fi
export AGENT2API_PROXY_HOME="$DATA_DIR"
export AGENT2API_HOST="$HOST"
export AGENT2API_PROXY_PORT="$PORT"
export AGENT2API_UI_DIR="$MODDIR/ui"
export AGENT2API_CAPTCHA_ENABLED=1
export AGENT2API_SELF_UPDATE=1
export HOME="$DATA_DIR"
mkdir -p "$DATA_DIR"

echo $$ > "$SUPPID"

# ── 脱离 App cgroup（防 MIUI 后台冻结，关键）──────────────────
# 从 App 会话（WebUI exec / 管理器）孵化的进程继承 App 的 cgroup，
# 熄屏后会被系统冻结（wchan=do_freezer_trap）→ 守护僵死、占着单实例
# 锁却不再拉起网关（「停止后无法启动」的根因）。挪到根 cgroup 即免冻结。
echo $$ > /sys/fs/cgroup/cgroup.procs 2>/dev/null
echo $$ > /dev/cpuctl/cgroup.procs 2>/dev/null

# ── 单实例锁（mkdir 原子 + PID 校验，参考 agent2api-magisk）──────
# 防多个守护并存：部署/重启被中断时旧守护可能没杀干净，新守护再起就会
# 出现「一个网关健康占端口、其它守护不停撞墙重试」的打架局面。
LOCKDIR="/data/adb/agent2api/supervisor.lock.d"
if ! mkdir "$LOCKDIR" 2>/dev/null; then
  _old=$(cat "$LOCKDIR/owner" 2>/dev/null)
  if [ -n "$_old" ] && kill -0 "$_old" 2>/dev/null \
     && grep -aq "supervisor.sh" "/proc/$_old/cmdline" 2>/dev/null; then
    # 真有活的守护在跑，本实例直接退
    exit 0
  fi
  rm -rf "$LOCKDIR" 2>/dev/null
  mkdir "$LOCKDIR" 2>/dev/null || exit 0
fi
echo $$ > "$LOCKDIR/owner"
trap 'rm -rf "$LOCKDIR" 2>/dev/null' EXIT

# ── 清孤儿：上一代守护崩溃/被杀时留下的网关实例（占着端口）────────
kill_gateway_all() {
  for _p in /proc/[0-9]*; do
    _pid=${_p#/proc/}
    [ "$_pid" = "$$" ] && continue
    [ -r "$_p/cmdline" ] || continue
    if grep -aq "ld-linux" "$_p/cmdline" 2>/dev/null && grep -aq "agent2api-server" "$_p/cmdline" 2>/dev/null; then
      kill "$_pid" 2>/dev/null
    fi
  done
  killall agent2api-server 2>/dev/null
  sleep 1
  for _p in /proc/[0-9]*; do
    _pid=${_p#/proc/}
    [ "$_pid" = "$$" ] && continue
    [ -r "$_p/cmdline" ] || continue
    if grep -aq "ld-linux" "$_p/cmdline" 2>/dev/null && grep -aq "agent2api-server" "$_p/cmdline" 2>/dev/null; then
      kill -9 "$_pid" 2>/dev/null
    fi
  done
}
kill_gateway_all

FAIL=0
DNS_TICK=0
while :; do
  if [ -f "$STOPFLAG" ]; then rm -f "$STOPFLAG"; exit 0; fi
  [ -f "$MODDIR/disable" ] && exit 0
  [ -f "$MODDIR/remove" ] && exit 0
  [ -f "$BIN" ] || exit 0

  # ── 权限自愈（KernelSU 开机会把安装后新增文件重置 0644）──────
  chmod 755 "$BIN" 2>/dev/null
  chmod 755 "$GLIBC"/* 2>/dev/null

  # 日志滚动（>2MB 归档）
  if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 2097152 ]; then
    mv -f "$LOG" "$LOG.old"
  fi

  # ── 启动前置：DNS 自适应（resolv/nsswitch/gai 三件套）────────
  dns_bootstrap

  # ── 启动前置：插件同步（android-bin + PT_INTERP）+ UI 补丁重放 ──
  sh "$MODDIR/sync-plugins.sh" >/dev/null 2>&1
  sh "$MODDIR/patch-ui.sh" >/dev/null 2>&1

  T0=$(date +%s)
  # glibc 二进制经 loader 运行；--argv0 让进程名回归 agent2api-server
  # （pidof / killall / 状态检查全部正常工作）
  "$LOADER" --argv0 agent2api-server --library-path "$GLIBC" "$BIN" >> "$LOG" 2>&1 &
  CHILD=$!
  echo $CHILD > "$PIDFILE"

  # 健康等待 + 动态描述（后台，不挡主循环）
  (
    i=0
    while [ $i -lt 20 ]; do
      sleep 1
      if busybox wget -qO- "http://127.0.0.1:$PORT/health" 2>/dev/null | grep -q '"ok"'; then
        if [ -x "$KSUD" ]; then
          export KSU_MODULE=agent2api
          $KSUD module config set override.description "Agent2API v3.3.0-beta.6 · 运行中 @ $HOST:$PORT（glibc+守护+DNS自适应）· 面板 http://127.0.0.1:$PORT/" 2>/dev/null
        fi
        break
      fi
      i=$((i+1))
    done
  ) &

  wait $CHILD
  RC=$?
  T1=$(date +%s)
  RAN=$((T1 - T0))
  if [ $RAN -ge 300 ]; then
    FAIL=1
  else
    FAIL=$((FAIL + 1))
  fi
  BACKOFF=3
  N=1
  while [ $N -lt $FAIL ] && [ $BACKOFF -lt 60 ]; do
    BACKOFF=$((BACKOFF * 2))
    N=$((N + 1))
  done
  [ $BACKOFF -gt 60 ] && BACKOFF=60
  echo "[supervisor] 网关退出 rc=$RC（本次运行 ${RAN}s，第 $FAIL 次失败）→ ${BACKOFF}s 后自动重启" >> "$LOG"
  sleep $BACKOFF

  # 周期性 DNS 刷新（每 5 轮退避周期或网关稳定运行后检查一次）
  DNS_TICK=$((DNS_TICK + 1))
  if [ $((DNS_TICK % 5)) = 0 ]; then
    dns_refresh_if_changed 2>/dev/null
  fi
done
