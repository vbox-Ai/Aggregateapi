#!/system/bin/sh
# ── Agent2API KernelSU 模块 · 开机完成后兜底 ─────────────────
# service.sh 在 late_start 已拉起守护；这里兜底：若整个链路没起来（被杀/失败），补一次。
MODDIR=${0%/*}
[ -f "$MODDIR/disable" ] && exit 0
[ -f "$MODDIR/remove" ] && exit 0
sleep 5
pidof agent2api-server >/dev/null 2>&1 && exit 0
sh "$MODDIR/control.sh" start
exit 0
